<?php
require_once("deliveries.php");

$fr = $_POST["from"];

$rc = htmlspecialchars($_POST["receiver"], ENT_QUOTES, 'UTF-8');
//$rc = ESAPI.encoder().encodeForJavaScript( request.getParameter($_POST["receiver"]) );

if(isset($_POST["receiver"]) && !empty($_POST["receiver"]) && isset($_POST["acc"]) && !empty($_POST["acc"]) && isset($_POST["amount"]) && !empty($_POST["amount"]))
{
	addTransfer($_POST["from"], $rc, $_POST["acc"], $_POST["amount"]);
}
else
{
	header("location: /Raiffeisen/transfer.php");
}

header("location: /Raiffeisen/home.php");

?>