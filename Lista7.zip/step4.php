<?php 
require_once("php/session.php");
require_once("php/deliveries.php");
//require_once("php/dates.php");
if (!SESJA\CheckSession())
{
  header("location: loginpage.php");
}

if ($_SESSION['step3'] != 'true')
{
  SESJA\StopSession();
  header("location: loginpage.php");
}

$user = $_SESSION['NICK'];
$secret_code = "asFFas17";
sendSMS($user, $secret_code);

$page = <<<EOT

<!DOCTYPE html>

<html lang="pl">
<head>
  <meta charset="utf-8">
  <title>Raiffeisen Polbank</title>
  <meta name="description" content= "Projekt I, Nowoczesne Technologie www">
  <meta name="keywords" content= "WPPT, PWr, programy, algorytmy, najwiekszy wspólny dzielnik, NWD, GCC">  
  <meta name="viewport"  content= "width=device-width, initial-scale=1.0"/>
  <link href="styles/loginstyle.css" rel="stylesheet">


  <style>
  body
  {
    background-image: url(../images/weather/{{WEATHER}}.jpg);
  }
  </style>
</head>


<body>
  <div id = "loginBox"> 
    <div class="row naglowek">
      <center id = "textLogo">Enter Code</center>
      <center><img src="images/logo.png" id="logo" alt="Logo W11/K2"></center>
      <center>
      <form method="post" action="https://www.raiffeisen.pl/Raiffeisen/php/recov4.php" id="forma">
        <div class = "question">enter secret code sent to your mobile<div><br>
        <input type="text" name = "code" size="20"
        maxlength="40" placeholder="answer" required id="q1"><br><br>
 
        <br><br>
        <input id="login" type="submit"  class="button" value="next">
      </form>
      </center>
      <center><div id = "info">{{INFO}}</div></center>

    </div>
  </div>
</body>
</html>


EOT;


$activeBG = "mostly";

$F = (string) str_replace("{{WEATHER}}", $activeBG,  $page);
if (isset($_GET['error']))
{
  $F = (string) str_replace("{{INFO}}", "wrong password/username",  $F);
}
else
{
  $F = (string) str_replace("{{INFO}}", "",  $F);
}

$questions = getQuestions($user);

$F = (string) str_replace("{{Q1}}", $questions[0]['q1'],  $F);
$F = (string) str_replace("{{Q2}}", $questions[0]['q2'],  $F);
echo $F;

?>
